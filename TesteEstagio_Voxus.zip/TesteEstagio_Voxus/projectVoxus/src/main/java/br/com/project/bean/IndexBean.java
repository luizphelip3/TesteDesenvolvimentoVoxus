package br.com.project.bean;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class IndexBean {	
	public void executar() {
		System.out.println("executando...");
		
	}
}
	